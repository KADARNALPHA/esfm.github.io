import os
import network
import time
import urequests
import machine
from lib.connect import wlan
from machine import I2C, Pin, Timer, RTC
from i2c_lcd import I2cLcd
import ntptime
import gc
import urandom
  # let LCD boot up
users = [] # Initialize the users list
usrdir = None # Initialize User Home Directory variable
liu = None # Initialize Logged In User variable
liup = None
for ii in open("/usr/launchd.list").readlines():
    exec(open(ii.strip()).read())
def fixlen(s, l):
    s = str(s)
    if len(s) >= l:
        return s[:l]
    return s + " " * (l - len(s))


def login():
    global users, usrdir, liu, liup # Set the following variables to this scope
    try:
        lines = open("/usr/.autologin").readlines()
        
        for i in open("usr/.usrs").readlines(): # Read the users list on flash
           users.append({"name": i.strip().split(":")[0], "pass": i.strip().split(":")[1]}) # Interpet and write to the users list
        incorrect = True
        while incorrect:
            username = lines[0].strip()
            password = lines[1].strip()
            fnd = False # Initialize Found User Variable
            for ii in users:
                if ii["name"] == username: # Check if the current dict of the list's name is equal to what the user inputted
                    if ii["pass"] == password: # Similar to username
                        usrdir = f"/home/{ii['name']}" # Set the according user directory
                        liu = ii["name"] # Set the Logged In User
                        liup = ii["pass"]
                        fnd = True
                        incorrect = False
                    else:
                        print("Autologin invalid.")
                        raise Exception("g")
                    break
            if fnd:
                print(f"Logged user {username} in successfully.")
    except:
        for i in open("usr/.usrs").readlines(): # Read the users list on flash
           users.append({"name": i.strip().split(":")[0], "pass": i.strip().split(":")[1]}) # Interpet and write to the users list
        incorrect = True
        while incorrect:
            username = input("Login: ")
            password = input("Passphrase: ")
            fnd = False # Initialize Found User Variable
            for ii in users:
                if ii["name"] == username: # Check if the current dict of the list's name is equal to what the user inputted
                    if ii["pass"] == password: # Similar to username
                        usrdir = f"/home/{ii['name']}" # Set the according user directory
                    
                        liu = ii["name"] # Set the Logged In User
                        liup = ii["pass"]
                        fnd = True
                        incorrect = False
                    else:
                        print("Incorrect password. Please try again")
                    break
            if fnd:
                print(f"Logged user {username} in successfully.")
            
login() # login
ntptime.host = "216.239.35.0" # Google time server for UTC
ssid = input("NSSID: ")
password = input("NPASS: ")

wlan = network.WLAN(network.STA_IF) # initialize the global wlan
wlan.active(True) # activate it
wlan.connect(ssid, password) # connect

t0 = time.time()

while not wlan.isconnected():
    if time.time() - t0 > 10:
        print("espian: Wi-Fi timeout failed to connect")
        break
    time.sleep(1)


try:
    r = urequests.get("3.3.3.3") # edit this
    raw = r.text
    r.close()

    date, time_ = raw.strip().split(" ")
    year, month, day = map(int, date.split("-"))
    hour, minute, second = map(int, time_.split(":"))

    rtc = RTC()
    rtc.datetime((year, month, day, 0, hour, minute, second, 0))
    print("espian: LAN time synced ✅")
except Exception as e:
    print("espian: LAN sync failed 💀", e)


lcdexist = True
try:
    i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=400000)
      # let LCD boot up
    lcd = I2cLcd(i2c, 0x27, 2, 16)  # 0x27 = your I2C address, 2 rows, 16 columns
      # let LCD boot up
    lcdon = False
    lcd.backlight_off()
except:
    print("Warning: Running headless")
    lcdon = False
    lcdexist = False
pdt = None

def path_info(path):
    try:
        mode = os.stat(path)[0]
        is_dir = (mode & 0x4000) != 0
        return True, is_dir
    except OSError:
        return False, False
    
def exists(path):
    try:
        mode = os.stat(path)[0]
        return True
    except OSError:
        return False

try:
    open(f"{usrdir}/.config/.hushlogin").close()
    print("Welcome to Espian 10.04 Hubble")
except:
    pass

def normalize_path(path):
    parts = []
    for part in path.split('/'):
        if part == '' or part == '.':
            continue
        elif part == '..':
            if parts:
                parts.pop()
        else:
            parts.append(part)
    return '/' + '/'.join(parts) if parts else '/'

try:
    open("/usr/.autologin")
    autologinr = True
except:
    autologinr = False
PATH = []
cwd = usrdir
cwdf = cwd.replace(usrdir, "~")
home = usrdir
wd = [{"name": "wlan0", "obj": wlan}]

for i in open(f"{usrdir}/.config/.path").readlines():
    PATH.append(i.strip())
    
num = 0
fpdt = None

def tick(timer):
    global pdt
    global fpdt
    dt = RTC().datetime()
    pdt = dt
    hour = (dt[4] + 3) % 24  # UTC+3 Cairo summer offset
    minute = dt[5]
    
    suffix = "AM"
    if hour >= 12:
        suffix = "PM"
    if hour > 12:
        hour -= 12
    if hour == 0:
        hour = 12
    if lcdon and lcdexist:

        lcd.move_to(0, 0)
        lcd.putstr(" " * 16)  # clear line
        lcd.move_to(0, 0)
        lcd.putstr("{:02d}:{:02d} {}".format(hour, minute, suffix))
        fpdt = "{:02d}:{:02d} {}".format(hour, minute, suffix)
        
def tick2(timer):
    global loop  # 👈 non-blocking async socket still works in background
    if lcdon and lcdexist:
        pass
    elif not lcdon and lcdexist:
        lcd.backlight_off()
    elif not lcdon and not lcdexist:
        pass
tick(1)
if lcdexist:
    lcd.move_to(0, 1)
    lcd.putstr("espian clock")

tim = Timer(0)  # Timer 0
tim2 = Timer(1)
# Init the timer to call `tick` every 1000ms
tim.init(period=60000, mode=Timer.PERIODIC, callback=tick)
tim2.init(period=1, mode=Timer.PERIODIC, callback=tick2)
hostname = "cmp"
deepsleep = False
running = True
def cmd_ls(parts):
    print(fixlen("FILENAME", 20) +  " SIZE")
    for i in os.listdir(cwd):
        print(fixlen(i, 20) + str(os.stat(cwd + "/" + i)[6] // 1024) + " KB")

def cmd_sleep(parts):
    global deepsleep, lcdon
    deepsleep = True
    lcdon = False
    time.sleep(0.1)
    print("\033[2J\033[H")
    print("In DeepSleep Mode. Click the RESET button to wake ESP32 up")
    machine.deepsleep()

def cmd_ramstat(parts):
    free = gc.mem_free() // 1024
    used = gc.mem_alloc() // 1024
    total = free + used
    print(f"{used} KB/{total} KB")

def cmd_cd(parts):
    global cwd, cwdf
    if len(parts) < 2:
        return
    target = parts[1]
    targetf = target.replace("~", usrdir)
    if targetf != "/":
        if target == "..":
            if cwd != "/":
                cwd = "/".join(cwd.rstrip("/").split("/")[:-1])
                if cwd == "":
                    cwd = "/"
        else:
            raw_path = cwd + "/" + target
            new_path = normalize_path(raw_path)
            exists_, is_dir = path_info(new_path)
            if not exists_:
                raw_path = targetf
                new_path = normalize_path(raw_path)
                exists_, is_dir = path_info(new_path)
                if not exists_:
                    print(f"espian: cd: {target}: No such file or directory")
                    return
                if not is_dir:
                    print(f"espian: cd: {target}: Not a directory")
                    return
                cwd = new_path
            elif not is_dir:
                print(f"espian: cd: {target}: Not a directory")
            else:
                cwd = new_path
        cwdf = cwd.replace(usrdir, "~")
    else:
        cwd = target
        cwdf = cwd.replace(usrdir, "~")

def cmd_mkdir(parts):
    try:
        os.mkdir(f"{cwd}/{parts[1]}")
    except Exception as e:
        print(e)

def cmd_time(parts):
    print(fpdt)

def cmd_cat(parts):
    if len(parts) < 2:
        return
    try:
        target = parts[1]
        if not target.startswith("/"):
            target = cwd + "/" + target
        target = normalize_path(target)
        exists_, is_dir = path_info(target)
        if not exists_:
            print(f"espian: cat: {parts[1]}: No such file or directory")
        elif is_dir:
            print(f"espian: cat: {parts[1]}: Is a directory")
        else:
            print(open(target).read())
    except Exception as e:
        print(e)
def cmd_exit(parts):
    global running
    print("espian: shutting down...")
    running = False

def cmd_wget(parts):
    if len(parts) < 3:
        return
    try:
        if wlan.isconnected():
            valid = False
            try:
                response = urequests.get(parts[1])
                valid = True
            except ValueError:
                print(f"espian: wget: {parts[1]} is not a valid url")
            if valid:
                if response.status_code != 404:
                    if parts[2].lower() == "w":
                        open(cwd + "/" + parts[1].split("/")[-1], "w").write(response.text)
                    elif parts[2].lower() == "wb":
                        open(cwd + "/" + parts[1].split("/")[-1], "wb").write(response.content)
                    else:
                        print(f"espian: wget: {parts[2]} is not a mode")
                else:
                    print(f"espian: wget: URL {parts[1]} does not exist")
            else:
                print("espian: wget: no WiFi connection")
    except Exception as e:
        print(e)

def cmd_clear(parts):
    print("\033[2J\033[H", end="")

def cmd_df(parts):
    if len(parts) < 2:
        print("Usage: df -b | -k | -m | -g")
        return
    stat = os.statvfs("/")
    free = stat[0] * stat[3]
    if parts[1] == "-b":
        print("Free space:", free, "B")
    elif parts[1] == "-k":
        print("Free space:", free // 1024, "KB")
    elif parts[1] == "-m":
        print("Free space:", free // (1024 * 1024), "MB")
    elif parts[1] == "-g":
        print("Free space: {:.8f} GB".format(free / (1024 * 1024 * 1024)))
    else:
        print(f"df: unknown flag {parts[1]}")

def cmd_size(parts):
    if len(parts) < 3:
        print("Usage: size <filename> -b | -kb | -mb | -gb")
        return
    target = parts[1]
    flag = parts[2].lower()
    if not target.startswith("/"):
        target = cwd + "/" + target
    target = normalize_path(target)
    if not exists(target):
        print(f"size: {parts[1]}: No such file")
        return
    _, is_dir = path_info(target)
    if is_dir:
        print(f"size: {parts[1]} is a directory")
        return
    size = os.stat(target)[6]
    if flag == "-b":
        print(f"{size} B")
    elif flag == "-kb":
        print(f"{size / 1024:.2f} KB")
    elif flag == "-mb":
        print(f"{size / (1024 * 1024):.2f} MB")
    elif flag == "-gb":
        print(f"{size / (1024 * 1024 * 1024):.6f} GB")
    else:
        print(f"size: unknown flag '{flag}'")
def cmd_whoami(parts):
    print(liu)
def cmd_rmdir(parts):
    try:
        os.rmdir(f"{cwd}/{parts[1]}")
    except Exception as e:
        print(e)

def cmd_touch(parts):
    if len(parts) < 2:
        return
    try:
        open(parts[1], "w").write("")
    except Exception as e:
        print(e)

def cmd_ver(parts):
    print(" ************         OS: Espian 10.04 Hubble")
    print(" ************")
    print(" *****        	    HOST: ESP32-WROOM-32")
    print(" *****")
    print(" ************ 	    FLASH: 4MB")
    print(" ************")
    print(" *****        	    CPU: XTENSA LX6")
    print(" *****")
    print(" ************ 	    GPIO: 38")
    print(" ************")
def cmd_iwctl(parts):
    while True:
        inputr = input("iwctl> ").strip()
        if not inputr:
            continue

        partsr = inputr.split(" ")
        cmdr = partsr[0]

        if cmdr == "device":
            if len(partsr) < 2:
                continue
            if partsr[1] == "list":
                for i in wd:
                    print(f"NAME: {i['name']} OBJ: {i['obj']}")
        
        elif cmdr == "station":
            if len(partsr) < 3:
                continue
            found = False
            obj = None
            for ii in wd:
                if partsr[1] == ii["name"]:
                    found = True
                    obj = ii["obj"]
                    break
            if found:
                if partsr[2] == "scan":
                    pass  # not implemented
                elif partsr[2] == "get-networks":
                    print("Not implemented yet.")
                elif partsr[2] == "connect":
                    if len(partsr) < 4:
                        continue
                    passw = input("Passphrase: ")
                    try:
                        obj.connect(partsr[3], passw)
                    except OSError:
                        print(f"iwctl: internal error occured while connecting to network '{partsr[3]}'.")
                    time.sleep(15)
                    if obj.isconnected():
                        pass
                    else:
                        print("iwctl: timeout")
        
        elif cmdr == "exit":
            break

def cmd_lcdon(parts):
    global lcdon
    if lcdexist:
        lcdon = True
        tick(1)
        lcd.backlight_on()

def cmd_lcdoff(parts):
    global lcdon
    if lcdexist:
        lcdon = False
        tick(1)
        lcd.backlight_off()
def cmd_autologin(parts):
    try:
        open("/usr/.autologin", "w").write(f"{liu}\n{liup}")
    except Exception as e:
        print(e)
def makedirs(path):
    parts = path.split("/")
    current = ""
    for part in parts:
        current += "/" + part
        try:
            os.mkdir(current)
        except:
            pass  # folder might already exist
def extract_tar(file_path, extract_to="."):
    def read_block(f):
        return f.read(512)

    def parse_header(block):
        name = block[0:100].decode().rstrip("\0")
        size_str = block[124:136].decode().rstrip("\0").strip()
        size = int(size_str or "0", 8)
        return name, size

    with open(file_path, "rb") as f:
        while True:
            block = read_block(f)
            if block == b"" or block == b"\0" * 512:
                break  # End of archive
            name, size = parse_header(block)
            if not name:
                break

            full_path = extract_to + "/" + name

            if full_path.endswith("/"):
                # it's a folder
                try:
                    os.mkdir(full_path)
                except OSError:
                    pass  # folder might already exist
                continue

            # make any folders if needed
            folder_path = "/".join(full_path.split("/")[:-1])
            if folder_path and not folder_path == ".":
                try:
                    makedirs(folder_path)
                except:
                    pass  # folder might exist already

            # read file data (aligned to 512)
            content = f.read((size + 511) & ~511)

            with open(full_path, "wb") as out:
                out.write(content[:size])

            print("Extracted:", full_path)
def randint(a, b):
    return a + urandom.getrandbits(8) % (b - a + 1)
def choice(seq):
    return seq[randint(0, len(seq) - 1)]
alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
al = []
for i in alphabet:
    al.append(i)
def system(cmdstr):
    # Simulate typing this into your shell
    global cwd, cwdf
    parts = cmdstr.strip().split()
    if not parts:
        return

    cmd = parts[0]
    def rstr(length):
        result = ""
        for i in range(length):
            result += choice(al)
        return result
    if cmd == "ls":
        cmd_ls(parts)
    elif cmd == "sleep":
        cmd_sleep(parts)
    elif cmd == "epen":
        sub = parts[1]
        if sub == "install":
            stri = rstr(10)
            extract_tar(cwd + "/" + parts[1], f"/tmp/{stri}")
            def path_info(path):
                try:
                    mode = os.stat(path)[0]
                    is_dir = (mode & 0x4000) != 0
                    return True, is_dir
                except OSError:
                    return False, False

            def copy_file(src, dest):
                with open(src, "rb") as fsrc:
                    with open(dest, "wb") as fdest:
                        while True:
                            buf = fsrc.read(512)
                            if not buf:
                                break
                            fdest.write(buf)

            def copy_recursive(src, dest):
                exists, is_dir = path_info(src)
                if not exists:
                    print("copy: source doesn't exist")
                    return

                if not is_dir:
                    copy_file(src, dest)
                else:
                    try:
                        os.mkdir(dest)
                    except:
                        pass  # maybe already exists
                    for entry in os.listdir(src):
                        s_path = src + "/" + entry
                        d_path = dest + "/" + entry
                        _, is_subdir = path_info(s_path)
                        if is_subdir:
                            copy_recursive(s_path, d_path)
                        else:
                            copy_file(s_path, d_path)

            # Example usage:
            for i in os.listdir(f"/tmp/{stri}/usr"):
                copy_recursive(f"/tmp/{stri}/usr/{i}", "/usr/{i}")

            
            
            
    elif cmd == "rm":
        cmd_rm(parts)
    elif cmd == "ramstat":
        cmd_ramstat(parts)
    elif cmd == "cd":
        cmd_cd(parts)
    elif cmd == "mkdir":
        cmd_mkdir(parts)
    elif cmd == "time":
        cmd_time(parts)
    elif cmd == "cat":
        cmd_cat(parts)
    elif cmd == "wget":
        cmd_wget(parts)

    elif cmd == "iwctl":
        cmd_iwctl(parts)
    elif cmd == "exit":
        cmd_exit(parts)
    elif cmd == "clear":
        cmd_clear(parts)
    elif cmd == "df":
        cmd_df(parts)
    elif cmd == "size":
        cmd_size(parts)
    elif cmd == "rmdir":
        cmd_rmdir(parts)
    elif cmd == "touch":
        cmd_touch(parts)
            
    elif cmd == "ver":
        cmd_ver(parts)
    elif cmd == "lcdon":
        cmd_lcdon(parts)
    elif cmd == "lcdoff":
        
        cmd_lcdoff(parts)
    else:
        found = False
        execpath = ""
        ncmd = cmd
        if cmd.endswith(".py"):
            ncmd = cmd
        elif not cmd.endswith("."):
            ncmd = cmd + ".py"
        for i in PATH:
            full = i + "/" + ncmd
            if exists(full):
                execpath = full
                found = True
                break

        if not found:
            print(f"{cmd}: command not found")
        else:
            try:
                scope = {"__args__": parts[1:], "shell": "esh", "os": "espian"}
                exec(open(execpath).read(), scope)
            except Exception as e:
                print(f"espian: {execpath}: script failed with error: {e}")
def cmd_rm(parts):
    try:
        os.remove(parts[1])
    except Exception as e:
        print(e)
while running:
    if not deepsleep:
        command = input(f"{liu}@{hostname}:{cwdf}$ ").strip()
        if command:
            system(command)


