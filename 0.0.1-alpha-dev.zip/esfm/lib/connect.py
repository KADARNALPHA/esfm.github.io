import network
ssid = 'Superdomy'
password = 'Domy@2015####**'

wlan = network.WLAN(network.STA_IF)  # station mode
wlan.active(True)