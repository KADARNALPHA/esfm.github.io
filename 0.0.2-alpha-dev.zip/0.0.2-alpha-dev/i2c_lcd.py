from lcd_api import LcdApi
from machine import I2C
import time

# Defines
MASK_RS = 0x01
MASK_RW = 0x02
MASK_E  = 0x04
MASK_BACKLIGHT = 0x08

# Commands
LCD_FUNCTIONSET = 0x20
LCD_CLEARDISPLAY = 0x01
LCD_ENTRYMODESET = 0x04
LCD_DISPLAYCONTROL = 0x08
LCD_CURSORSHIFT = 0x10
LCD_SETCGRAMADDR = 0x40
LCD_SETDDRAMADDR = 0x80

LCD_DISPLAYON = 0x04
LCD_DISPLAYOFF = 0x00
LCD_ENTRYLEFT = 0x02
LCD_ENTRYSHIFTDECREMENT = 0x00
LCD_2LINE = 0x08
LCD_5x8DOTS = 0x00
LCD_4BITMODE = 0x00

class I2cLcd(LcdApi):
    def __init__(self, i2c, i2c_addr, num_lines, num_columns):
        self.i2c = i2c
        
        self.i2c_addr = i2c_addr
        self.num_lines = num_lines
        self.num_columns = num_columns
        self.backlight = MASK_BACKLIGHT
        self._write_byte(0)
        time.sleep_ms(20)
        self._send_init_nibble(0x03)
        time.sleep_ms(5)
        self._send_init_nibble(0x03)
        time.sleep_ms(1)
        self._send_init_nibble(0x03)
        self._send_init_nibble(0x02)
        cmd = LCD_FUNCTIONSET | LCD_2LINE | LCD_5x8DOTS | LCD_4BITMODE
        self.hal_write_command(cmd)
        self.hal_write_command(LCD_DISPLAYCONTROL | LCD_DISPLAYON)
        self.clear()
        self.cursor_x = 0
        self.cursor_y = 0

        self.hal_write_command(LCD_ENTRYMODESET | LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT)

    def hal_write_command(self, cmd):
        self._write_byte((cmd & 0xF0) | self.backlight)
        self._strobe((cmd & 0xF0) | self.backlight)
        self._write_byte(((cmd << 4) & 0xF0) | self.backlight)
        self._strobe(((cmd << 4) & 0xF0) | self.backlight)

    def hal_write_data(self, data):
        self._write_byte((data & 0xF0) | MASK_RS | self.backlight)
        self._strobe((data & 0xF0) | MASK_RS | self.backlight)
        self._write_byte(((data << 4) & 0xF0) | MASK_RS | self.backlight)
        self._strobe(((data << 4) & 0xF0) | MASK_RS | self.backlight)

    def _strobe(self, data):
        self.i2c.writeto(self.i2c_addr, bytes([data | MASK_E]))
        time.sleep_us(500)
        self.i2c.writeto(self.i2c_addr, bytes([data & ~MASK_E]))
        time.sleep_us(500)

    def _write_byte(self, data):
        self.i2c.writeto(self.i2c_addr, bytes([data]))

    def _send_init_nibble(self, nibble):
        self._write_byte((nibble << 4) | self.backlight)
        self._strobe((nibble << 4) | self.backlight)

    def hal_backlight(self, state):
        self.backlight = MASK_BACKLIGHT if state else 0
        self._write_byte(self.backlight)
