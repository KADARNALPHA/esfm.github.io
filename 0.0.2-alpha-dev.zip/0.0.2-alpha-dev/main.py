import os
import network
import time
import urequests
from lib.connect import wlan
from machine import I2C, Pin, Timer, RTC
from i2c_lcd import I2cLcd
import lib.cmd as cmds
from lib.gdt import *
import utime
import sys
for ii in open("/usr/launchd.list").readlines():
    exec(open(ii.strip()).read())
            
usrdir, liu, liup = login() # login
ssid = input("Network SSID: ")
password = input("Network Password: ")
print("1) UTC-8:00")
print("2) UTC-7:00")
print("3) UTC-6:00")
print("4) UTC-5:00")
print("5) UTC-4:00")
print("6) UTC-3:00")
print("7) UTC-2:00")
print("8) UTC-1:00")
print("9) UTC")
print("10) UTC+1:00")
print("11) UTC+2:00")
print("12) UTC+3:00")
print("13) UTC+4:00")
print("14) UTC+5:00")
print("15) UTC+6:00")
print("16) UTC+7:00")
print("17) UTC+8:00")
tz = input("Num: ")
tzi = int(tz)
wlan = network.WLAN(network.STA_IF) # initialize the global wlan
wlan.active(True) # activate it
wlan.connect(ssid, password) # connect

t0 = utime.time()

while not wlan.isconnected():
    if utime.time() - t0 > 10:
        log(WIFI, "espian: Wi-Fi timeout failed to connect", ERR)
        break
    time.sleep(1)


try:
    r = urequests.get("http://192.168.100.4")
    raw = r.text
    r.close()

    date, time_ = raw.strip().split(" ")
    year, month, day = map(int, date.split("-"))
    hour, minute, second = map(int, time_.split(":"))

    rtc = RTC()
    rtc.datetime((year, month, day, 0, hour, minute, second, 0))
    log(WIFI, "espian: LAN time synced", INF)
except Exception as e:
    log(WIFI, "espian: LAN sync failed {}".format(e), ERR)


lcdexist = True
try:
    i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=400000)
      # let LCD boot up
    lcd = I2cLcd(i2c, 0x27, 2, 16)  # 0x27 = your I2C address, 2 rows, 16 columns
      # let LCD boot up
    lcdon = False
    lcd.backlight_off()
except:
    log(SC, "Running headless", WARN)
    lcdon = False
    lcdexist = False
pdt = None

def path_info(path):
    try:
        mode = os.stat(path)[0]
        is_dir = (mode & 0x4000) != 0
        return True, is_dir
    except OSError:
        return False, False
    
def exists(path):
    try:
        mode = os.stat(path)[0]
        return True
    except OSError:
        return False

try:
    open(f"{usrdir}/.config/.hushlogin").close()
    print("Welcome to Espian 10.05 Serti")
except:
    pass

def normalize_path(path):
    parts = []
    for part in path.split('/'):
        if part == '' or part == '.':
            continue
        elif part == '..':
            if parts:
                parts.pop()
        else:
            parts.append(part)
    return '/' + '/'.join(parts) if parts else '/'

try:
    open("/usr/.autologin")
    autologinr = True
except:
    autologinr = False
PATH = []
print(usrdir)
cwd = usrdir
cwdf = cwd.replace(usrdir, "~")
home = usrdir
wd = [{"name": "wlan0", "obj": wlan}]
cmds.cwd = cwd
cmds.cwdf = cwdf
cmds.usrdir = usrdir
cmds.liu = liu
cmds.liup = liup
sudo_timestamp = 0
for i in open(f"{usrdir}/.config/.path").readlines():
    PATH.append(i.strip())
    
num = 0
fpdt = None

def tick(timer):
    global pdt
    global fpdt
    try:
        dt = RTC().datetime()
    except:
        pass
    pdt = dt
    if tzi == 1:
        hour = (dt[4] - 8) % 24  # UTC+3 Cairo summer offset
    elif tzi == 2:
        hour = (dt[4] - 7) % 24  # UTC+3 Cairo summer offset
    elif tzi == 3:
        hour = (dt[4] - 6) % 24  # UTC+3 Cairo summer offset
    elif tzi == 4:
        hour = (dt[4] - 5) % 24  # UTC+3 Cairo summer offset
    elif tzi == 5:
        hour = (dt[4] - 4) % 24  # UTC+3 Cairo summer offset
    elif tzi == 6:
        hour = (dt[4] - 3) % 24  # UTC+3 Cairo summer offset
    elif tzi == 7:
        hour = (dt[4] - 2) % 24  # UTC+3 Cairo summer offset
    elif tzi == 8:
        hour = (dt[4] - 1) % 24  # UTC+3 Cairo summer offset
    elif tzi == 9:
        hour = (dt[4]) % 24  # UTC+3 Cairo summer offset
    elif tzi == 10:
        hour = (dt[4] + 1) % 24  # UTC+3 Cairo summer offset
    elif tzi == 11:
        hour = (dt[4] + 2) % 24  # UTC+3 Cairo summer offset
    elif tzi == 12:
        hour = (dt[4] + 3) % 24  # UTC+3 Cairo summer offset
    elif tzi == 13:
        hour = (dt[4] + 4) % 24  # UTC+3 Cairo summer offset
    elif tzi == 14:
        hour = (dt[4] + 5) % 24  # UTC+3 Cairo summer offset
    elif tzi == 15:
        hour = (dt[4] + 6) % 24  # UTC+3 Cairo summer offset
    elif tzi == 16:
        hour = (dt[4] + 7) % 24  # UTC+3 Cairo summer offset
    elif tzi == 17:
        hour = (dt[4] + 8) % 24  # UTC+3 Cairo summer offset
    
    minute = dt[5]
    
    suffix = "AM"
    if hour >= 12:
        suffix = "PM"
    if hour > 12:
        hour -= 12
    if hour == 0:
        hour = 12
    if lcdon and lcdexist:

        lcd.move_to(0, 0)
        lcd.putstr(" " * 16)  # clear line
        lcd.move_to(0, 0)
        lcd.putstr("{:02d}:{:02d} {}".format(hour, minute, suffix))
        fpdt = "{:02d}:{:02d} {}".format(hour, minute, suffix)
        
def tick2(timer):
    global loop  # 👈 non-blocking async socket still works in background
    if lcdon and lcdexist:
        pass
    elif not lcdon and lcdexist:
        lcd.backlight_off()
    elif not lcdon and not lcdexist:
        pass
tick(1)
if lcdexist:
    lcd.move_to(0, 1)
    lcd.putstr("espian clock")

tim = Timer(0)  # Timer 0
tim2 = Timer(1)
# Init the timer to call `tick` every 1000ms
tim.init(period=60000, mode=Timer.PERIODIC, callback=tick)
tim2.init(period=1, mode=Timer.PERIODIC, callback=tick2)
hostname = "cmp"
deepsleep = False
running = True

def system(cmdstr):
    # Simulate typing this into your shell
    global cwd, cwdf, liu, liup, pliu, pliup
    parts = cmdstr.strip().split()
    if not parts:
        return

    cmd = parts[0]
    def rstr(length):
        result = ""
        for i in range(length):
            result += choice(al)
        return result
    if cmd == "ls":
        cmds.cmd_ls(parts)
    elif cmd == "launchd":
        cmds.cmd_launchd(parts)
    elif cmd == "sleep":
        cmds.cmd_sleep(parts)
    elif cmd == "nvram":
        cmds.cmd_nvram(parts)
    elif cmd == "echo":
        cmds.cmd_echo(parts)
    elif cmd == "man":
        cmds.cmd_man(parts)
    elif cmd == "sudo":
        global sudo_timestamp
        import time

        current_time = utime.time()
        if current_time - sudo_timestamp < 60:
            # within grace period
            liu_prev = cmds.liu
            liup_prev = cmds.liup
            rpass = None
            for ii in open("/usr/.usrs").readlines():
                if ii.split(":")[0] == "root":
                    rpass = ii.strip().split(":")[1]
            cmds.liu = "root"
            cmds.liup = rpass
            cmdstr = " ".join(parts[1:])
            system(cmdstr)
            cmds.liu = liu_prev
            cmds.liup = liup_prev
        else:
            # expired or never entered
            rpass = None
            for ii in open("/usr/.usrs").readlines():
                if ii.split(":")[0] == "root":
                    rpass = ii.strip().split(":")[1]
            inc = True
            num = 0
            while inc:
                if num != 3:
                    passw = input("[sudo] password for root: ")
                    if passw == rpass:
                        inc = False
                        sudo_timestamp = utime.time()  # ⏰ update sudo time
                    else:
                        print("Sorry, try again")
                    num += 1
                else:
                    print("sudo: 3 failed attempts")
                    return
            liu_prev = cmds.liu
            liup_prev = cmds.liup
            cmds.liu = "root"
            cmds.liup = rpass
            cmdstr = " ".join(parts[1:])
            system(cmdstr)
            cmds.liu = liu_prev
            cmds.liup = liup_prev

    elif cmd == "epen":
        cmds.cmd_epen(parts)
    elif cmd == "rm":
        cmds.cmd_rm(parts)
    elif cmd == "ramstat":
        cmds.cmd_ramstat(parts)
    elif cmd == "cd":
        cmds.cmd_cd(parts)
    elif cmd == "mkdir":
        cmds.cmd_mkdir(parts)
    elif cmd == "time":
        cmds.cmd_time(parts, pdt)
    elif cmd == "cat":
        cmds.cmd_cat(parts)
    elif cmd == "wget":
        cmds.cmd_wget(parts)

    elif cmd == "iwctl":
        cmds.cmd_iwctl(parts)
    elif cmd == "exit":
        sys.exit(0)
    elif cmd == "clear":
        cmds.cmd_clear(parts)
    elif cmd == "df":
        cmds.cmd_df(parts)
    elif cmd == "size":
        cmds.cmd_size(parts)
    elif cmd == "rmdir":
        cmds.cmd_rmdir(parts)
    elif cmd == "touch":
        cmds.cmd_touch(parts)
            
    elif cmd == "ver":
        cmds.cmd_ver(parts)
    elif cmd == "lcdon":
        cmds.cmd_lcdon(parts)
    elif cmd == "nano":
        cmds.cmd_nano(parts)
    elif cmd == "lcdoff":
        cmds.cmd_lcdoff(parts)
    else:
        found = False
        execpath = ""
        ncmd = cmd
        if cmd.endswith(".py"):
            ncmd = cmd
        elif not cmd.endswith("."):
            ncmd = cmd + ".py"
        for i in PATH:
            full = i + "/" + ncmd
            if exists(full):
                execpath = full
                found = True
                break
        if not found:
            print(f"{cmd}: command not found")
        else:
            try:
                scope = {"__args__": parts[1:], "liu": cmds.liu, "liup": cmds.liup, "cwd": cmds.cwd}
                for ii in open("/usr/envar").readlines():
                    scope[ii.strip().split(" ")[0]] = " ".join(ii.strip().split(" ")[1:])
                exec(open(execpath).read(), scope)
            except Exception as e:
                print(f"espian: {execpath}: script failed with error: {e}")

while running:
    try:
        if not deepsleep:
            command = input(f"{cmds.liu}@{hostname}:{cmds.cwdf}$ ").strip()
            if command:
                system(command)
    except KeyboardInterrupt:
        print("^C")
        pass


