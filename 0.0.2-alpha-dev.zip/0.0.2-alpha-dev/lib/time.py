from machine import RTC
from gdt import *
import urequests
try:
    r = urequests.get("http://192.168.100.4")
    raw = r.text
    r.close()

    date, time_ = raw.strip().split(" ")
    year, month, day = map(int, date.split("-"))
    hour, minute, second = map(int, time_.split(":"))

    rtc = RTC()
    rtc.datetime((year, month, day, 0, hour, minute, second, 0))
    log(WIFI, "espian: LAN time synced", INF)
except Exception as e:
    log(WIFI, "espian: LAN sync failed {}".format(e), ERR)