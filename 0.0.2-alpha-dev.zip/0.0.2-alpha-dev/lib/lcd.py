from machine import I2C
from i2c_lcd import I2cLcd
from gdt import *
lcdexist = True
try:
    i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=400000)
      # let LCD boot up
    lcd = I2cLcd(i2c, 0x27, 2, 16)  # 0x27 = your I2C address, 2 rows, 16 columns
      # let LCD boot up
    lcdon = False
    lcd.backlight_off()
except:
    log(SC, "Running headless", WARN)
    lcdon = False
    lcdexist = False