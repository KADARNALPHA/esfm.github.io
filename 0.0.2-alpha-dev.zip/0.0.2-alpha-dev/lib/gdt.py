
import ujson
import os
def log(cat, message, severity):
    if verbose:
        print(f"[{cat.upper()}] [{severity.upper()}] {message}")
users = [] # Initialize the users list
usrdir = None # Initialize User Home Directory variable
liu = None # Initialize Logged In User variable
liup = None
conf = ujson.load(open("/boot/config.json"))
ERR = "error"
WARN = "warning"
INF = "info"
LOGON = "esfm.logon"
RTCW = "esfm.rtc"
WIFI = "esfm.itlwm"
SC = "esfm.screen"
import urandom
if "-v" in conf["NVRAM"]["7C436110-AB2A-4BBB-A880-FE41995C9F82"]["boot-args"]:
    verbose = True
else:
    verbose = False
def login():
    global users, usrdir, liu, liup # Set the following variables to this scope
    try:
        lines = open("/usr/.autologin").readlines()
        
        for i in open("usr/.usrs").readlines(): # Read the users list on flash
           users.append({"name": i.strip().split(":")[0], "pass": i.strip().split(":")[1]}) # Interpet and write to the users list
           log(LOGON, "Added user " + i.strip().split(":")[0] + " to users", INF)

        incorrect = True
        while incorrect:
            username = lines[0].strip()
            password = lines[1].strip()
            fnd = False # Initialize Found User Variable
            for ii in users:
                if ii["name"] == username: # Check if the current dict of the list's name is equal to what the user inputted
                    if ii["pass"] == password: # Similar to username
                        usrdir = f"/home/{ii['name']}" # Set the according user directory
                        print(usrdir)
                        log(LOGON, "Set usrdir", INF)
                        liu = ii["name"] # Set the Logged In User
                        log(LOGON, "Set LIU", INF)
                        liup = ii["pass"]
                        log(LOGON, "Set LIUP", INF)
                        fnd = True
                        log(LOGON, "Acknowledge that this user was found.", INF)
                        incorrect = False
                        log(LOGON, "Set incorrect", INF)
                    else:
                        log(LOGON, "Autologin Invalid", ERR)
                        raise Exception("g")
                    break
            if fnd:
                log(LOGON, f"Logged user {username} in successfully.", INF)
                return usrdir, liu, liup
    except:
        for i in open("usr/.usrs").readlines(): # Read the users list on flash
           users.append({"name": i.strip().split(":")[0], "pass": i.strip().split(":")[1]}) # Interpet and write to the users list
           log(LOGON, "Added user {} to users".format(i.strip().split(':')[0]), INF)
        incorrect = True
        while incorrect:
            username = input("Login: ")
            password = input("Passphrase: ")
            fnd = False # Initialize Found User Variable
            for ii in users:
                if ii["name"] == username: # Check if the current dict of the list's name is equal to what the user inputted
                    if ii["pass"] == password: # Similar to username
                        usrdir = f"/home/{ii['name']}" # Set the according user directory
                        print(usrdir)
                        liu = ii["name"] # Set the Logged In User
                        liup = ii["pass"]
                        fnd = True
                        incorrect = False
                    else:
                        print("Incorrect password. Please try again")
                    break
            if fnd:
                print(f"Logged user {username} in successfully.")
                return usrdir, liu, liup
def normalize_path(path):
    parts = []
    for part in path.split('/'):
        if part == '' or part == '.':
            continue
        elif part == '..':
            if parts:
                parts.pop()
        else:
            parts.append(part)
    return '/' + '/'.join(parts) if parts else '/'
def fixlen(s, l):
    s = str(s)
    if len(s) >= l:
        return s[:l]
    return s + " " * (l - len(s))

try:
    open("/usr/.autologin")
    autologinr = True
except:
    autologinr = False
def path_info(path):
    try:
        mode = os.stat(path)[0]
        is_dir = (mode & 0x4000) != 0
        return True, is_dir
    except OSError:
        return False, False
    
def exists(path):
    try:
        mode = os.stat(path)[0]
        return True
    except OSError:
        return False
