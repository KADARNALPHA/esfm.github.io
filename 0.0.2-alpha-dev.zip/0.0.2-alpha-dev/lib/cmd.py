try:
    from lcd import lcdexist, lcdon, lcd
except:
    from lcd import lcdexist, lcdon
from gdt import *
import gc
import machine
import os
import time
import urequests
from connect import wlan
def cmd(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyboardInterrupt:
            print("")
    return wrapper
@cmd
def cmd_ls(parts):
    print(fixlen("FILENAME", 20) +  " SIZE")
    for i in os.listdir(cwd):
        print(fixlen(i, 20) + str(os.stat(cwd + "/" + i)[6] // 1024) + " KB")
def cmd_sleep(parts):
    global deepsleep, lcdon
    deepsleep = True
    lcdon = False
    time.sleep(0.1)
    print("\033[2J\033[H")
    print("In DeepSleep Mode. Click the RESET button to wake ESP32 up")
    machine.deepsleep()
@cmd
def cmd_ramstat(parts):
    free = gc.mem_free() // 1024
    used = gc.mem_alloc() // 1024
    total = free + used
    print(f"{used} KB/{total} KB")
@cmd
def cmd_cd(parts):
    global cwd, cwdf, usrdir
    if len(parts) < 2:
        return
    target = parts[1]
    targetf = target.replace("~", usrdir)
    if targetf != "/":
        if target == "..":
            if cwd != "/":
                cwd = "/".join(cwd.rstrip("/").split("/")[:-1])
                if cwd == "":
                    cwd = "/"
        else:
            raw_path = cwd + "/" + target
            new_path = normalize_path(raw_path)
            exists_, is_dir = path_info(new_path)
            if not exists_:
                raw_path = targetf
                new_path = normalize_path(raw_path)
                exists_, is_dir = path_info(new_path)
                if not exists_:
                    print(f"espian: cd: {target}: No such file or directory")
                    return
                if not is_dir:
                    print(f"espian: cd: {target}: Not a directory")
                    return
                cwd = new_path
            elif not is_dir:
                print(f"espian: cd: {target}: Not a directory")
            else:
                cwd = new_path
        cwdf = cwd.replace(usrdir, "~")
    else:
        cwd = target
        cwdf = cwd.replace(usrdir, "~")
@cmd
def cmd_mkdir(parts):
    try:
        os.mkdir(f"{cwd}/{parts[1]}")
    except Exception as e:
        print(e)
@cmd
def cmd_time(parts, pdt):
    print(pdt)
@cmd
def cmd_cat(parts):
    if len(parts) < 2:
        return
    try:
        target = parts[1]
        if not target.startswith("/"):
            target = cwd + "/" + target
        target = normalize_path(target)
        exists_, is_dir = path_info(target)
        if not exists_:
            print(f"espian: cat: {parts[1]}: No such file or directory")
        elif is_dir:
            print(f"espian: cat: {parts[1]}: Is a directory")
        else:
            print(open(target).read())
    except Exception as e:
        print(e)
def cmd_exit(parts):
    global running
    print("espian: shutting down...")
    running = False
def cmd_nvram(parts):
    if len(parts) == 1:
        for uuid, vars in conf["NVRAM"].items():
            for k, v in vars.items():
                print(f"{uuid}:{k} = {v}")
    elif len(parts) == 2:
        key = parts[1]
        for uuid, vars in conf["NVRAM"].items():
            if key in vars:
                print(f"{uuid}:{key} = {vars[key]}")
    elif len(parts) == 3:
        key = parts[1]
        value = parts[2]
        for uuid in conf["NVRAM"]:
            if key in conf["NVRAM"][uuid]:
                conf["NVRAM"][uuid][key] = value
                ujson.dump(conf, open("/boot/config.json", "w"))
                print(f"{key} set to {value}")
                return
        print(f"{key}: no such variable")
@cmd
def cmd_wget(parts):
    if len(parts) < 3:
        return
    try:
        if wlan.isconnected():
            valid = False
            try:
                response = urequests.get(parts[1])
                valid = True
            except ValueError:
                print(f"espian: wget: {parts[1]} is not a valid url")
            if valid:
                if response.status_code != 404:
                    if parts[2].lower() == "w":
                        open(cwd + "/" + parts[1].split("/")[-1], "w").write(response.text)
                    elif parts[2].lower() == "wb":
                        open(cwd + "/" + parts[1].split("/")[-1], "wb").write(response.content)
                    else:
                        print(f"espian: wget: {parts[2]} is not a mode")
                else:
                    print(f"espian: wget: URL {parts[1]} does not exist")
            else:
                print("espian: wget: no WiFi connection")
    except Exception as e:
        print(e)

def cmd_clear(parts):
    print("\033[2J\033[H", end="")
@cmd
def cmd_df(parts):
    if len(parts) < 2:
        print("Usage: df -b | -k | -m | -g")
        return
    stat = os.statvfs("/")
    free = stat[0] * stat[3]
    if parts[1] == "-b":
        print("Free space:", free, "B")
    elif parts[1] == "-k":
        print("Free space:", free // 1024, "KB")
    elif parts[1] == "-m":
        print("Free space:", free // (1024 * 1024), "MB")
    elif parts[1] == "-g":
        print("Free space: {:.8f} GB".format(free / (1024 * 1024 * 1024)))
    else:
        print(f"df: unknown flag {parts[1]}")
@cmd
def cmd_size(parts):
    if len(parts) < 3:
        print("Usage: size <filename> -b | -kb | -mb | -gb")
        return
    target = parts[1]
    flag = parts[2].lower()
    if not target.startswith("/"):
        target = cwd + "/" + target
    target = normalize_path(target)
    if not exists(target):
        print(f"size: {parts[1]}: No such file")
        return
    _, is_dir = path_info(target)
    if is_dir:
        print(f"size: {parts[1]} is a directory")
        return
    size = os.stat(target)[6]
    if flag == "-b":
        print(f"{size} B")
    elif flag == "-kb":
        print(f"{size / 1024:.2f} KB")
    elif flag == "-mb":
        print(f"{size / (1024 * 1024):.2f} MB")
    elif flag == "-gb":
        print(f"{size / (1024 * 1024 * 1024):.6f} GB")
    else:
        print(f"size: unknown flag '{flag}'")
def cmd_whoami(parts):
    print(liu)
@cmd
def cmd_rmdir(parts):
    try:
        os.rmdir(f"{cwd}/{parts[1]}")
    except Exception as e:
        print(e)
@cmd
def cmd_touch(parts):
    if len(parts) < 2:
        return
    try:
        open(parts[1], "w").write("")
    except Exception as e:
        print(e)
@cmd
def cmd_ver(parts):
    print(" ************         OS: Espian 10.05 Serti")
    print(" ************")
    print(" *****        	    HOST: ESP32-WROOM-32")
    print(" *****")
    print(" ************ 	    FLASH: 4MB")
    print(" ************")
    print(" *****        	    CPU: XTENSA LX6")
    print(" *****")
    print(" ************ 	    GPIO: 38")
    print(" ************")
@cmd
def cmd_iwctl(parts):
    while True:
        inputr = input("iwctl> ").strip()
        if not inputr:
            continue

        partsr = inputr.split(" ")
        cmdr = partsr[0]

        if cmdr == "device":
            if len(partsr) < 2:
                continue
            if partsr[1] == "list":
                for i in wd:
                    print(f"NAME: {i['name']} OBJ: {i['obj']}")
        
        elif cmdr == "station":
            if len(partsr) < 3:
                continue
            found = False
            obj = None
            for ii in wd:
                if partsr[1] == ii["name"]:
                    found = True
                    obj = ii["obj"]
                    break
            if found:
                if partsr[2] == "scan":
                    pass  # not implemented
                elif partsr[2] == "get-networks":
                    print("Not implemented yet.")
                elif partsr[2] == "connect":
                    if len(partsr) < 4:
                        continue
                    passw = input("Passphrase: ")
                    try:
                        obj.connect(partsr[3], passw)
                    except OSError:
                        print(f"iwctl: internal error occured while connecting to network '{partsr[3]}'.")
                    time.sleep(15)
                    if obj.isconnected():
                        pass
                    else:
                        print("iwctl: timeout")
        
        elif cmdr == "exit":
            break
@cmd
def cmd_lcdon(parts):
    global lcdon
    if lcdexist:
        lcdon = True
        tick(1)
        lcd.backlight_on()
@cmd
def cmd_lcdoff(parts):
    global lcdon
    if lcdexist:
        lcdon = False
        tick(1)
        lcd.backlight_off()
@cmd
def cmd_autologin(parts):
    try:
        open("/usr/.autologin", "w").write(f"{liu}\n{liup}")
    except Exception as e:
        print(e)
def makedirs(path):
    parts = path.split("/")
    current = ""
    for part in parts:
        current += "/" + part
        try:
            os.mkdir(current)
        except:
            pass  # folder might already exist
def extract_tar(file_path, extract_to="."):
    def read_block(f):
        return f.read(512)

    def parse_header(block):
        name = block[0:100].decode().rstrip("\0")
        size_str = block[124:136].decode().rstrip("\0").strip()
        size = int(size_str or "0", 8)
        return name, size

    with open(file_path, "rb") as f:
        while True:
            block = read_block(f)
            if block == b"" or block == b"\0" * 512:
                break  # End of archive
            name, size = parse_header(block)
            if not name:
                break

            full_path = extract_to + "/" + name

            if full_path.endswith("/"):
                # it's a folder
                try:
                    os.mkdir(full_path)
                except OSError:
                    pass  # folder might already exist
                continue

            # make any folders if needed
            folder_path = "/".join(full_path.split("/")[:-1])
            if folder_path and not folder_path == ".":
                try:
                    makedirs(folder_path)
                except:
                    pass  # folder might exist already

            # read file data (aligned to 512)
            content = f.read((size + 511) & ~511)

            with open(full_path, "wb") as out:
                out.write(content[:size])

            print("Extracted:", full_path)
def remove_line(path, line_to_remove):
    lines = open(path, "r").readlines()
    with open(path, "w") as f:
        for line in lines:
            if line.strip() != line_to_remove:
                f.write(line)
def sudo(func):
    def wrapper(*args, **kwargs):
        if liu == "root":
            return func(*args, **kwargs)
        else:
            print("This command needs to be run as root.")
            return None
    return wrapper

@sudo
def cmd_launchd(parts):
    sub = parts[1]
    if sub == "list":
        for i in open("/usr/launchd.list").readlines():
            print(i)
    elif sub == "add":
        open("/usr/launchd.list", "a").write(parts[2] + "\n")
    elif sub == "remove":
        remove_line("/usr/launchd.list", parts[2])
alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
al = []
sudo_timestamp = 0
for i in alphabet:
    al.append(i)
@sudo
@cmd
def cmd_epen(parts):
    exexu = True
    if len(parts) < 3:
        exexu = False
    if exexu:
            sub = parts[1]
            if sub == "install":
                stri = rstr(10)
                try:
                    extract_tar(cwd + "/" + parts[1], f"/tmp/{stri}")
                except OSError:
                    print("epen: File not found")
                def path_info(path):
                    try:
                        mode = os.stat(path)[0]
                        is_dir = (mode & 0x4000) != 0
                        return True, is_dir
                    except OSError:
                        return False, False

                def copy_file(src, dest):
                    with open(src, "rb") as fsrc:
                        with open(dest, "wb") as fdest:
                            while True:
                                buf = fsrc.read(512)
                                if not buf:
                                    break
                                fdest.write(buf)

                def copy_recursive(src, dest):
                    exists, is_dir = path_info(src)
                    if not exists:
                        print("copy: source doesn't exist")
                        return

                    if not is_dir:
                        copy_file(src, dest)
                    else:
                        try:
                            os.mkdir(dest)
                        except:
                            pass  # maybe already exists
                        for entry in os.listdir(src):
                            s_path = src + "/" + entry
                            d_path = dest + "/" + entry
                            _, is_subdir = path_info(s_path)
                            if is_subdir:
                                copy_recursive(s_path, d_path)
                            else:
                                copy_file(s_path, d_path)

                # Example usage:
                try:
                    for i in os.listdir(f"/tmp/{stri}/usr"):
                        copy_recursive(f"/tmp/{stri}/usr/{i}", "/usr/{i}")
                except OSError:
                    pass
def cmd_echo(parts):
    print(" ".join(parts[1:]))
def cmd_man(parts):
    cmds = []
    for i in open("/etc/man.db").readlines():
        cmds.append({"cmd": i.strip().split(" ")[0], "desc": " ".join(i.strip().split(" ")[1:])})
    print(fixlen("CMD", 14) + "DESCRIPTION")
    try:
        for ii in cmds:
            if ii["cmd"] == parts[1]:
                print(fixlen(ii["cmd"], 14) + ii["desc"])
                break
    except:
        for ii in cmds:
            print(fixlen(ii["cmd"], 14) + ii["desc"])
def randint(a, b):
    return a + urandom.getrandbits(8) % (b - a + 1)
def choice(seq):
    return seq[randint(0, len(seq) - 1)]

@sudo
def cmd_rm(parts):
    try:
        os.remove(parts[1])
    except Exception as e:
        print(e)